package deckOfCards;

import java.util.ArrayList;

//
public class Driver {

	// for testing only
}
//
///*
// * 1 card with 7 cattle heads�number 55 8 cards with 5 cattle heads�multiples of
// * 11 (except 55): 11, 22, 33, 44, 66, 77, 88, 99 10 cards with 3 cattle
// * heads�multiples of ten: 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 9 cards with
// * 2 cattle heads�multiples of five that are not multiples of ten (except 55):
// * 5, 15, 25, 35, 45, 65, 75, 85, 95 76 cards with 1 cattle head�the rest of the
// * cards from 1 through 104
// */